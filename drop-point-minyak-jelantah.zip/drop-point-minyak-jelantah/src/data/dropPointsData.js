const dropPoints = [
  {
    id: 1,
    name: "Titik Drop Jelantah A",
    lat: -6.210000,
    lng: 106.845599,
    isOpen: true,
    description: "Buka Senin sampai Jumat, jam 08.00-16.00"
  },
  {
    id: 2,
    name: "Titik Drop Jelantah B",
    lat: -6.220000,
    lng: 106.832500,
    isOpen: false,
    description: "Tutup hari Sabtu dan Minggu"
  },
  {
    id: 3,
    name: "Titik Drop Jelantah C",
    lat: -6.200000,
    lng: 106.810000,
    isOpen: true,
    description: "Buka setiap hari jam 07.00-19.00"
  }
];

export default dropPoints;
